// ReceiveActivity.kt placeholder
